import subprocess,sys
subprocess.run([sys.executable,"lightwebpres","build",".","--lang",'en'],check=True)
