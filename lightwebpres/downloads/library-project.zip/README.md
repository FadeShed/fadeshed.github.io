# The neighbourhood library

An example briefing with a complete working note.

## Articles

1. [A small library. A shared place.](../en-single/publication.html#lwp/a/library.html) — A proposal to read, discuss and keep.
2. [Your ideas. Their own address.](../en-single/publication.html#lwp/a/ma-page.html) — One text. One page. To read and present.
