# The neighbourhood library

An example briefing with a complete working note.

## Articles

1. [A small library. A shared place.](../../../../../../../../../../tmp/opencode/lwp-refresh-v0661/lightwebpres/demo/library.html) — A proposal to read, discuss and keep.
2. [Your ideas. Their own address.](../../../../../../../../../../tmp/opencode/lwp-refresh-v0661/lightwebpres/demo/ma-page.html) — One text. One page. To read and present.
