# My first series

A starter project for LightWebPres.

## Articles

1. [Your ideas. Their own address.](../../../../home/runner/work/_temp/publication/lightwebpres/demo/ma-page.html) — One text. One page. To read and present.
