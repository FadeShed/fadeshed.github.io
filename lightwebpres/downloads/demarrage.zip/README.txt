From this directory:
python3 lightwebpres build . --lang en
Then open public/index.html. Edit sources/ma-page.md; keep its slugs stable.
