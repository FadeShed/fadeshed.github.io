# La bibliothèque de quartier

Un exemple de dossier avec sa note de travail complète.

## Articles

1. [Une petite bibliothèque. Un lieu commun.](../fr-single/publication.html#lwp/a/library.html) — Une proposition à lire, discuter et conserver.
2. [Vos idées. Leur propre adresse.](../fr-single/publication.html#lwp/a/ma-page.html) — Un texte. Une page. À lire et à présenter.
