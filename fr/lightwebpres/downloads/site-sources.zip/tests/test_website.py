"""Contracts for the website sources and its stdlib publication pipeline.

No network and no browser dependency. The complete publication, including
Pyodide, guide and downloads, is checked by tools/build_website.py in CI.
"""
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parent.parent


def load_tool(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'tools' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


builder = load_tool('build_website')
checker = load_tool('check_website')


class WebsitePublicationContracts(unittest.TestCase):
    def test_version_is_read_from_the_engine_not_a_second_constant(self):
        info = builder.engine_info()
        self.assertIn('VERSION = "' + info['version'] + '"',
                      (ROOT / 'lightwebpres').read_text())
        self.assertIn(info['status'], ('released', 'unreleased'))
        self.assertEqual(len(info['sha256']), 64)

    def test_inputs_are_existing_unique_files_without_generated_site(self):
        paths = builder.source_files()
        self.assertEqual(len(paths), len(set(paths)))
        self.assertTrue(all(p.is_file() for p in paths))
        self.assertFalse(any(ROOT / 'generated' / 'site' in p.parents for p in paths))

    def test_source_directories_are_never_publication_destinations(self):
        for path in (ROOT, ROOT.parent, ROOT / 'website', ROOT / 'tools',
                     ROOT / 'tests' / 'nested', ROOT / 'web'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                builder.validate_output(path)

    def test_unmarked_nonempty_output_is_not_erased(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)
            (path / 'valuable.txt').write_text('keep')
            with self.assertRaises(ValueError):
                builder.validate_output(path)
            self.assertEqual((path / 'valuable.txt').read_text(), 'keep')
            (path / builder.MARKER).write_text('generated')
            self.assertEqual(builder.validate_output(path), path)

    def test_output_cannot_be_a_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp)
            real = parent / 'real'
            real.mkdir()
            link = parent / 'link'
            try:
                link.symlink_to(real, target_is_directory=True)
            except OSError:
                self.skipTest('This platform does not allow test symlinks')
            with self.assertRaises(ValueError):
                builder.validate_output(link)

    def test_publication_restores_old_output_if_final_rename_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            staged, output = root / 'stage', root / 'site'
            staged.mkdir(); output.mkdir()
            (staged / 'index.html').write_text('new')
            (output / 'index.html').write_text('old')
            original = builder.os.replace
            def fail_once(source, destination):
                if Path(source).name.startswith('.site-new-'):
                    raise OSError('injected publication failure')
                return original(source, destination)
            with mock.patch.object(builder.os, 'replace', side_effect=fail_once):
                with self.assertRaises(OSError):
                    builder.publish(staged, output)
            self.assertEqual((output / 'index.html').read_text(), 'old')
            self.assertFalse(list(root.glob('.site-*-*')))
            # Even a failed rollback must leave the old bytes recoverable.
            def fail_publish_and_restore(source, destination):
                if Path(source).name.startswith(('.site-new-', '.site-old-')):
                    raise OSError('injected second failure')
                return original(source, destination)
            with mock.patch.object(builder.os, 'replace', side_effect=fail_publish_and_restore):
                with self.assertRaises(RuntimeError):
                    builder.publish(staged, output)
            backups = list(root.glob('.site-old-*'))
            self.assertEqual(len(backups), 1)
            self.assertEqual((backups[0] / 'index.html').read_text(), 'old')

    def test_zip_has_stable_bytes_and_stable_order(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / 'source.txt'; source.write_text('bonjour')
            first, second = root / 'a.zip', root / 'b.zip'
            entries = [('z.txt', source), ('a.txt', source)]
            builder.deterministic_zip(first, entries)
            builder.deterministic_zip(second, list(reversed(entries)))
            self.assertEqual(first.read_bytes(), second.read_bytes())
            with zipfile.ZipFile(first) as archive:
                self.assertEqual(archive.namelist(), ['a.txt', 'z.txt'])
                self.assertEqual(archive.infolist()[0].date_time, (1980, 1, 1, 0, 0, 0))

    def test_checker_sees_broken_anchors_and_project_root_links(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'index.html').write_text('<html lang="fr"><h1>Test</h1>'
                '<a href="#missing">Oops</a><a href="/root.html">Root</a></html>')
            errors, _ = checker.check(root)
            self.assertTrue(any('missing anchor #missing' in e for e in errors))
            self.assertTrue(any('root-relative URL' in e for e in errors))

    def test_template_alternatives_do_not_count_as_visible_headings(self):
        page = checker.Page('<html lang="fr"><h1>One</h1>'
                            '<template><h1>Alternative</h1></template></html>')
        self.assertEqual(page.h1, 1)
        self.assertEqual(page.language, 'fr')


class WebsiteIsALightWebPresSeries(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.series = Path(cls.temporary.name) / 'series'
        cls.public = Path(cls.temporary.name) / 'public'
        shutil.copytree(ROOT / 'website' / 'sources', cls.series / 'sources')
        shutil.copytree(ROOT / 'website' / 'templates', cls.series / 'templates')
        shutil.copy2(ROOT / 'website' / 'series.json', cls.series / 'series.json')
        (cls.series / 'sources' / 'img').mkdir()
        for name in builder.CAPTURES:
            shutil.copy2(ROOT / 'generated' / name, cls.series / 'sources' / 'img' / name)
        cls.output = builder.run(ROOT / 'lightwebpres', 'build', cls.series,
                                 '--lang', 'fr', '--output', cls.public)

    def test_six_real_articles_and_a_native_index_are_generated(self):
        self.assertEqual(len(list(self.public.glob('*.html'))), 7)
        index = (self.public / 'index.html').read_text()
        self.assertIn('lwp-presentation--lightwebpres-site', index)
        self.assertIn('lwp-presentation-index', index)
        self.assertEqual(checker.Page(index).h1, 1)
        self.assertIn('data-lwp-article-card', index)

    def test_sources_pass_strict_audit(self):
        output = builder.run(ROOT / 'lightwebpres', 'audit', self.series,
                             '--lang', 'fr', '--strict')
        self.assertNotIn('[WARNING]', output)

    def test_generated_files_match_verify(self):
        output = builder.run(ROOT / 'lightwebpres', 'verify', self.series,
                             '--lang', 'fr', '--output', self.public)
        self.assertIn('[OK] index.html', output)
        self.assertNotIn('[NEW]', output)

    def test_code_examples_do_not_become_extra_cover_slides(self):
        import re
        text = (self.public / 'ecrire.html').read_text()
        sections = re.findall(r'<section\b[^>]*class="([^"]*)"[^>]*>', text)
        self.assertEqual(sum('slide-cover' in classes.split() for classes in sections), 1)
        self.assertIn('&lt;!-- lwp:slide', text)
        self.assertTrue('id="champs-avant-texte"' in text)

    def test_light_variant_passes_the_same_audit(self):
        manifest = self.series / 'templates/kits/lightwebpres-site/1.0.0/manifest.json'
        original = manifest.read_text()
        data = json.loads(original)
        data['presets']['web']['theme'] = 'papier'
        try:
            manifest.write_text(json.dumps(data, ensure_ascii=False))
            output = builder.run(ROOT / 'lightwebpres', 'audit', self.series,
                                 '--lang', 'fr', '--strict')
            self.assertNotIn('[WARNING]', output)
        finally:
            manifest.write_text(original)


if __name__ == '__main__':
    unittest.main()
