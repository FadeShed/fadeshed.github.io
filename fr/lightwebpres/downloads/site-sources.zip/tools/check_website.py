#!/usr/bin/env python3
"""Check a built website without a browser or third-party Python packages.

Checks local HTML links/anchors, image and script references, project-site
relative paths, zip integrity, provenance and expected entry points.
It intentionally makes no claim about external URL availability or visuals.
"""
import argparse
from html.parser import HTMLParser
import json
from pathlib import Path
import sys
from urllib.parse import unquote, urlsplit
import zipfile


class Page(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.ids = set()
        self.links = []
        self.h1 = 0
        self.language = None
        self.template_depth = 0
        self.feed(source)

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if tag == 'template':
            self.template_depth += 1
        if tag == 'html':
            self.language = attrs.get('lang')
        if tag == 'h1' and not self.template_depth:
            self.h1 += 1
        if attrs.get('id'):
            self.ids.add(attrs['id'])
        for attribute in ('href', 'src', 'poster'):
            value = attrs.get(attribute)
            if value:
                self.links.append((self.getpos()[0], value))

    def handle_endtag(self, tag):
        if tag == 'template':
            self.template_depth = max(0, self.template_depth - 1)


def check(directory):
    root = Path(directory).resolve()
    errors = []
    pages = {p: Page(p.read_text(encoding='utf-8')) for p in root.rglob('*.html')}
    if not pages:
        return ['No HTML pages found'], {}
    local_links = 0
    for path, page in pages.items():
        if not page.language:
            errors.append('{}: missing document language'.format(path.relative_to(root)))
        for line, link in page.links:
            parsed = urlsplit(link)
            if parsed.scheme or parsed.netloc:
                continue
            if parsed.path.startswith('/'):
                errors.append('{}:{}: root-relative URL breaks a project site: {}'.format(
                    path.relative_to(root), line, link))
                continue
            target = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
            if target.is_dir():
                target /= 'index.html'
            if root != target and root not in target.parents:
                errors.append('{}:{}: link escapes the published site: {}'.format(path.name, line, link))
                continue
            local_links += 1
            if not target.is_file():
                errors.append('{}:{}: missing target {}'.format(path.relative_to(root), line, link))
            elif parsed.fragment and target in pages:
                anchor = unquote(parsed.fragment)
                if anchor not in pages[target].ids:
                    errors.append('{}:{}: missing anchor {}'.format(path.relative_to(root), line, link))
    expected = ['index.html', 'decouvrir.html', 'demarrer.html', 'ecrire.html',
                'apparence.html', 'publier.html', 'ressources.html',
                'demo/ma-page.html', 'guide/guide.html', 'themes.html',
                'web/index.html', 'web/lightwebpres', 'web/COPYING',
                'web/vendor/pyodide/pyodide.asm.wasm', '.nojekyll',
                'reference/agent/skills/lightwebpres/SKILL.md',
                'reference/agent/skills/sourced-presentation/references/evidence.md',
                'build-info.json']
    for name in expected:
        if not (root / name).is_file():
            errors.append('Missing required output: {}'.format(name))
    for name in expected[:7]:
        path = root / name
        if path in pages and pages[path].h1 != 1:
            errors.append('{}: expected one visible h1, found {}'.format(name, pages[path].h1))
    zips = []
    for name in ('demarrage', 'lightwebpres-cli', 'skills', 'site-sources'):
        archive = root / 'downloads' / (name + '.zip')
        if not archive.is_file():
            errors.append('Missing download: {}'.format(archive.name))
            continue
        try:
            with zipfile.ZipFile(str(archive)) as zf:
                bad = zf.testzip()
                if bad:
                    errors.append('Corrupt ZIP member: {}/{}'.format(archive.name, bad))
                for member in zf.namelist():
                    parts = Path(member).parts
                    if member.startswith('/') or '..' in parts:
                        errors.append('Unsafe ZIP member: {}'.format(member))
                zips.append(archive.name)
        except zipfile.BadZipFile as exc:
            errors.append(str(exc))
    provenance = root / 'build-info.json'
    if provenance.exists():
        info = json.loads(provenance.read_text(encoding='utf-8'))
        if info.get('schema') != 'lightwebpres.website-build/1':
            errors.append('Unrecognized build provenance schema')
        if info.get('engine', {}).get('status') not in ('released', 'unreleased'):
            errors.append('Missing explicit engine release status')
    summary = {'html_pages': len(pages), 'local_references_checked': local_links,
               'downloads_checked': len(zips), 'errors': len(errors)}
    return sorted(set(errors)), summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', nargs='?', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'generated/site')
    args = parser.parse_args()
    try:
        errors, summary = check(args.directory)
    except (OSError, ValueError) as exc:
        parser.exit(1, 'Website check failed: {}\n'.format(exc))
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if errors:
        for error in errors:
            print('ERROR: ' + error, file=sys.stderr)
        sys.exit(1)
    print('Website static checks passed.')


if __name__ == '__main__':
    main()
