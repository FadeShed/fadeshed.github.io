#!/usr/bin/env python3
"""Build the public website using the unmodified LightWebPres executable.

Python standard library only. All HTML pages are engine output: the main
series, the example, the official guide and the native theme gallery.
Never patch generated HTML. Publish only the completed staging directory.

    python3 tools/build_website.py
    python3 tools/build_website.py --output /path/to/new/site
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'website'
DEFAULT_OUTPUT = ROOT / 'generated' / 'site'
MARKER = '.lightwebpres-website'
DOCUMENTS = ('README.md', 'GUIDE.md', 'GLOSSARY.md', 'specifications.md',
             'CHANGELOG.md', 'DECISIONS.md', 'AGENTS.md', 'COPYING',
             'COPYING.EXCEPTION', 'THIRD-PARTY-NOTICES.md')
LICENCES = ('COPYING', 'COPYING.EXCEPTION', 'THIRD-PARTY-NOTICES.md')
CAPTURES = ('product-responsive.png', 'themes-featured.png')


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n',
                    encoding='utf-8')


def run(*args):
    env = {k: v for k, v in os.environ.items() if not k.startswith('LWP_')}
    env.update(TERM='dumb', PYTHONIOENCODING='utf-8')
    command = [sys.executable] + [str(arg) for arg in args]
    result = subprocess.run(command, cwd=str(ROOT), env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, timeout=180)
    if result.returncode or '[ERROR]' in result.stdout:
        raise RuntimeError('{}\n{}'.format(' '.join(command), result.stdout))
    return result.stdout


def engine_info():
    text = (ROOT / 'lightwebpres').read_text(encoding='utf-8')
    match = re.search(r'^VERSION\s*=\s*"([^"]+)"', text, re.M)
    if not match:
        raise RuntimeError('No VERSION found in the executable')
    version = match.group(1)
    changelog = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8')
    unreleased = bool(re.search(r'^## Unreleased — ' + re.escape(version) + r'\s*$',
                               changelog, re.M))
    if not unreleased and not re.search(r'^## v' + re.escape(version) + r'\s*$',
                                        changelog, re.M):
        raise RuntimeError('The engine version has no changelog section')
    return {'version': version, 'status': 'unreleased' if unreleased else 'released',
            'sha256': hashlib.sha256((ROOT / 'lightwebpres').read_bytes()).hexdigest()}


def source_files():
    files = [SOURCE / 'series.json', ROOT / 'lightwebpres']
    for directory in (SOURCE, ROOT / 'agent' / 'skills', ROOT / 'examples' / 'kits', ROOT / 'web'):
        files.extend(p for p in directory.rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts
                     and not any(part.startswith('.lwp-') for part in p.parts))
    files.extend(ROOT / name for name in DOCUMENTS)
    files.extend(ROOT / 'generated' / name for name in CAPTURES)
    files.extend(ROOT / name for name in
                 ('tools/build_website.py', 'tools/check_website.py',
                  'tools/check_website_browser.py', 'tests/test_website.py',
                  'tools/build_guide.py', 'tools/guide-deck.md',
                  '.github/workflows/pages.yml'))
    return sorted(set(files), key=lambda p: p.relative_to(ROOT).as_posix())


def deterministic_zip(destination, entries):
    """Stable archive timestamps and ordering; no symlinks or implicit files."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(str(destination), 'w', zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name, path in sorted(entries, key=lambda e: e[0]):
            if path.is_symlink():
                raise RuntimeError('Refusing symlink in download: {}'.format(path))
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())


def validate_output(output):
    output = Path(os.path.abspath(str(output)))
    if output.is_symlink():
        raise ValueError('Output must not be a symlink: {}'.format(output))
    output = output.resolve()
    # An explicit output may be elsewhere, but cannot consume an input tree.
    for protected in (ROOT, SOURCE, ROOT / 'tools', ROOT / 'tests', ROOT / 'web',
                      ROOT / 'agent', ROOT / 'examples'):
        if output == protected or output in protected.parents or protected in output.parents:
            # generated/site and other generated subdirectories are intended outputs.
            if protected == ROOT and ROOT / 'generated' in output.parents:
                continue
            raise ValueError('Output overlaps source files: {}'.format(output))
    if output.exists() and not output.is_dir():
        raise ValueError('Output is not a directory: {}'.format(output))
    if output.exists() and any(output.iterdir()) and not (output / MARKER).is_file():
        raise ValueError('Refusing to replace an unmarked directory: {}'.format(output))
    return output


def publish(staged, output):
    """Replace a complete site on the same filesystem, restoring on failure."""
    output.parent.mkdir(parents=True, exist_ok=True)
    incoming = Path(tempfile.mkdtemp(prefix='.' + output.name + '-new-', dir=str(output.parent)))
    backup = None
    published = False
    try:
        shutil.copytree(str(staged), str(incoming), dirs_exist_ok=True)
        if output.exists():
            backup = Path(tempfile.mkdtemp(prefix='.' + output.name + '-old-', dir=str(output.parent)))
            backup.rmdir()
            os.replace(str(output), str(backup))
        try:
            os.replace(str(incoming), str(output))
            published = True
        except BaseException:
            if backup is not None:
                try:
                    os.replace(str(backup), str(output))
                except OSError as restore_error:
                    raise RuntimeError('Publication and rollback failed; the previous '
                                       'output is preserved at {}'.format(backup)) from restore_error
                backup = None
            raise
    finally:
        if incoming.exists():
            shutil.rmtree(str(incoming))
        if published and backup is not None and backup.exists():
            shutil.rmtree(str(backup))


def build(output=DEFAULT_OUTPUT):
    output = validate_output(output)
    info = engine_info()
    input_files = source_files()
    for path in input_files:
        if not path.is_file():
            raise RuntimeError('Missing build input: {}'.format(path))
    scratch = ROOT / 'work' / 'tmp'
    scratch.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='website-', dir=str(scratch)) as temporary:
        work = Path(temporary)
        series = work / 'series'
        public = work / 'public'
        shutil.copytree(str(SOURCE / 'sources'), str(series / 'sources'))
        shutil.copytree(str(SOURCE / 'templates'), str(series / 'templates'))
        config = json.loads((SOURCE / 'series.json').read_text(encoding='utf-8'))
        config['series_meta']['version'] = 'Moteur {} · {}'.format(
            info['version'], 'version de travail' if info['status'] == 'unreleased' else 'version publiée')
        write_json(series / 'series.json', config)
        image_dir = series / 'sources' / 'img'
        image_dir.mkdir(exist_ok=True)
        for name in CAPTURES:
            shutil.copy2(str(ROOT / 'generated' / name), str(image_dir / name))
        reports = {}
        for command in ('build', 'audit', 'verify'):
            options = ['--strict'] if command == 'audit' else []
            # audit does not accept --output: it renders the same source in memory.
            destination = ['--output', public] if command != 'audit' else []
            reports[command] = run(ROOT / 'lightwebpres', command, series,
                                   '--lang', 'fr', *options, *destination)
            print('Site: {} OK'.format(command), flush=True)

        example = work / 'demarrage'
        shutil.copytree(str(SOURCE / 'example'), str(example))
        for name in ('lightwebpres',) + LICENCES:
            shutil.copy2(str(ROOT / name), str(example / name))
        version_note = work / 'VERSION.txt'
        version_note.write_text('LightWebPres {}\nStatus: {}\nEngine SHA-256: {}\n'
                                'Source: https://github.com/Fade78/lightwebpres\n'
                                'This is the engine used by this site, not a claim about the latest release.\n'
                                .format(info['version'], info['status'], info['sha256']), encoding='utf-8')
        shutil.copy2(str(version_note), str(example / 'VERSION.txt'))
        (example / 'LIRE-MOI.txt').write_text(
            'Depuis ce dossier :\n  python3 lightwebpres build . --lang fr\n'
            'Puis ouvrir public/index.html.\n'
            'Modifiez sources/ma-page.md ; gardez ses slugs stables.\n'
            'Windows : remplacez python3 par python ou py.\n'
            'Gardez les licences avec le moteur.\n', encoding='utf-8')
        run(ROOT / 'lightwebpres', 'build', example, '--lang', 'fr',
            '--output', public / 'demo')
        run(ROOT / 'lightwebpres', 'audit', example, '--lang', 'fr', '--strict')
        run(ROOT / 'lightwebpres', 'verify', example, '--lang', 'fr', '--output', public / 'demo')
        print('Example: build, strict audit and verify OK', flush=True)
        run(ROOT / 'tools' / 'build_guide.py', '--output', public / 'guide')
        run(ROOT / 'lightwebpres', 'theme', 'gallery', public / 'themes.html', '--lang', 'fr')
        print('Official guide and native theme gallery rebuilt', flush=True)

        # Same Python engine; Pyodide is fully local and no CDN is introduced.
        shutil.copytree(str(ROOT / 'web'), str(public / 'web'),
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        for name in ('lightwebpres',) + LICENCES:
            shutil.copy2(str(ROOT / name), str(public / 'web' / name))
        references = public / 'reference'
        references.mkdir()
        for name in DOCUMENTS:
            shutil.copy2(str(ROOT / name), str(references / name))
        shutil.copytree(str(ROOT / 'agent'), str(references / 'agent'),
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        shutil.copy2(str(ROOT / 'web' / 'lwp_logo_icon.svg'), str(public / 'favicon.svg'))
        (public / '.nojekyll').write_text('', encoding='utf-8')
        (public / MARKER).write_text('Generated by tools/build_website.py. Do not edit output.\n', encoding='utf-8')
        write_json(public / 'build-info.json', {
            'schema': 'lightwebpres.website-build/1', 'engine': info,
            'language': 'fr', 'preset': config['series_meta']['presentation_preset'],
            'articles': [a['page_source'] for a in config['articles']],
            'checks': {'build': True, 'audit_strict': True, 'verify': True,
                       'example_build_audit_verify': True},
            'inputs': {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in input_files},
        })
        downloads = public / 'downloads'
        deterministic_zip(downloads / 'demarrage.zip',
            [('demarrage/' + p.relative_to(example).as_posix(), p)
             for p in example.rglob('*') if p.is_file()
             and not any(part.startswith('.lwp-') for part in p.parts)])
        deterministic_zip(downloads / 'lightwebpres-cli.zip',
            [(name, ROOT / name) for name in ('lightwebpres',) + LICENCES] + [('VERSION.txt', version_note)])
        deterministic_zip(downloads / 'skills.zip',
            [(p.relative_to(ROOT).as_posix(), p) for p in (ROOT / 'agent' / 'skills').rglob('*') if p.is_file()])
        # An explicit source overlay, not an incomplete claim to be the full repo.
        bundle_readme = work / 'SITE-SOURCES.txt'
        bundle_readme.write_text(
            'Sources du site LightWebPres\n\n'
            'Cette archive est un ajout au dépôt, pas une copie complète du moteur.\n'
            'Décompressez-la à la racine du dépôt correspondant au moteur de ce site.\n'
            'Le moteur, le guide, les captures et web/vendor viennent de ce dépôt.\n'
            'Puis : python3 tools/build_website.py\n'
            'Lire website/README.md pour la maintenance et le déploiement.\n', encoding='utf-8')
        overlay = [(p.relative_to(ROOT).as_posix(), p) for p in SOURCE.rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts
                   and not any(part.startswith('.lwp-') for part in p.parts)]
        for name in ('tools/build_website.py', 'tools/check_website.py',
                     'tools/check_website_browser.py', '.github/workflows/pages.yml',
                     'tests/test_website.py'):
            path = ROOT / name
            if path.exists():
                overlay.append((name, path))
        deterministic_zip(downloads / 'site-sources.zip', overlay + [('SITE-SOURCES.txt', bundle_readme)])
        # Never leak engine cleanup manifests or staging paths into the public artefact.
        for path in public.rglob('.lwp-*'):
            if path.is_file():
                path.unlink()
        run(ROOT / 'tools' / 'check_website.py', public)
        print('Internal links, assets and downloads OK', flush=True)
        publish(public, output)
    print('Website ready: {}'.format(output), flush=True)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    try:
        build(args.output)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        parser.exit(1, 'Website build failed: {}\n'.format(exc))


if __name__ == '__main__':
    main()
