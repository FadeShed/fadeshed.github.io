#!/usr/bin/env python3
"""Optional real Chromium checks for the generated LightWebPres website.

Requires the Python playwright package and its Chromium, or --chromium PATH.
Serves only the built output under /lightwebpres/ and tests the real Pyodide
builder. --render-only is an explicit reduced mode for managed environments
that disallow browser navigation: renders HTML in memory, measures layout,
checks themes/help, and verifies HTTP entry points with Python. It does NOT
claim browser navigation, fullscreen, preference persistence or Pyodide E2E.
No generated file is edited. No external network access is needed.
"""
import argparse
import base64
from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import tempfile
import threading
from urllib.parse import unquote, urlsplit
from urllib.request import urlopen
import zipfile

PAGES = ('index.html', 'decouvrir.html', 'demarrer.html', 'ecrire.html',
         'apparence.html', 'publier.html', 'ressources.html')
VIEWPORTS = ((1440, 1000), (768, 1024), (390, 844), (320, 740))
PREFIX = '/lightwebpres/'


@contextmanager
def serve(directory):
    root = directory.resolve()
    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def translate_path(self, path):
            relative = unquote(urlsplit(path).path)
            if not relative.startswith(PREFIX):
                return str(root / '__outside_publication__')
            candidate = (root / relative[len(PREFIX):]).resolve()
            if candidate != root and root not in candidate.parents:
                return str(root / '__outside_publication__')
            return str(candidate)
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, directory=str(root)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield 'http://127.0.0.1:{}{}'.format(server.server_port, PREFIX)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def render_source(path):
    """Inline local images only in the in-memory test document.

    about:blank cannot resolve relative images. This lets a managed browser
    render the exact image bytes without navigation or changing any file.
    """
    source = path.read_text(encoding='utf-8')
    replacements = {}
    def replace(match):
        url = match.group(2)
        parsed = urlsplit(url)
        if parsed.scheme or parsed.netloc:
            return match.group(0)
        target = (path.parent / unquote(parsed.path)).resolve()
        mime = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                '.svg': 'image/svg+xml', '.webp': 'image/webp'}.get(target.suffix.lower())
        if not mime or not target.is_file():
            return match.group(0)
        data = base64.b64encode(target.read_bytes()).decode('ascii')
        uri = 'data:' + mime + ';base64,' + data
        replacements[url] = uri
        return match.group(1) + uri + match.group(3)
    source = re.sub(r'(<img\b[^>]*?\bsrc=")([^"]+)(")', replace, source)
    # Runtime presentation alternatives also carry the same relative image URLs.
    for url, uri in replacements.items():
        source = source.replace(url, uri)
    return source


def check(root, screenshots=None, executable=None, render_only=False):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError('Install the optional Python playwright package and Chromium first.') from exc
    root = root.resolve()
    if not (root / 'index.html').is_file():
        raise ValueError('Build the site before running browser checks.')
    if screenshots:
        screenshots.mkdir(parents=True, exist_ok=True)
    report = {'mode': 'render-only' if render_only else 'http-browser',
              'prefix': PREFIX, 'layout_checks': [], 'checks': [], 'skipped': [],
              'console_errors': [], 'page_errors': []}
    with serve(root) as base, sync_playwright() as playwright:
        # HTTP under a project prefix is checked even in reduced rendering mode.
        for name in PAGES + ('demo/ma-page.html', 'guide/guide.html', 'themes.html',
                             'web/index.html', 'web/lightwebpres',
                             'downloads/demarrage.zip', 'web/vendor/pyodide/pyodide.asm.wasm'):
            with urlopen(base + name, timeout=20) as response:
                if response.status != 200:
                    raise AssertionError('HTTP entry point failed: ' + name)
                response.read()
        report['checks'].append('HTTP project-prefix entry points')
        launch = {'headless': True}
        if executable:
            launch['executable_path'] = executable
        browser = playwright.chromium.launch(**launch)
        context = browser.new_context(viewport={'width': 1440, 'height': 1000},
                                      reduced_motion='reduce', accept_downloads=True)
        def new_page(name):
            page = context.new_page()
            page.on('pageerror', lambda error: report['page_errors'].append(str(error)))
            page.on('console', lambda message: report['console_errors'].append(message.text)
                    if message.type == 'error' else None)
            if render_only:
                page.set_content(render_source(root / name), wait_until='load')
            else:
                page.goto(base + name, wait_until='networkidle')
            return page
        try:
            for name in PAGES:
                page = new_page(name)
                # Eagerly load below-fold images for the asset check.
                page.evaluate("document.querySelectorAll('img').forEach(i=>i.loading='eager')")
                page.wait_for_function('Array.from(document.images).every(i=>i.complete && i.naturalWidth>0)', timeout=10000)
                for width, height in VIEWPORTS:
                    page.set_viewport_size({'width': width, 'height': height})
                    page.wait_for_timeout(80)
                    dimensions = page.evaluate('''() => ({
                        width: innerWidth, scroll: document.documentElement.scrollWidth,
                        h1: Array.from(document.querySelectorAll('h1')).filter(e=>e.getClientRects().length).length
                    })''')
                    if dimensions['scroll'] > width + 2:
                        raise AssertionError('{} at {}px overflows to {}px'.format(name, width, dimensions['scroll']))
                    if dimensions['h1'] != 1:
                        raise AssertionError('{}: expected one rendered h1'.format(name))
                    report['layout_checks'].append({'page': name, 'width': width,
                                                    'horizontal_overflow': False})
                    if screenshots and name == 'index.html' and width in (1440, 390):
                        page.screenshot(path=str(screenshots / ('accueil-{}.png'.format(width))), full_page=True)
                        if width == 1440:
                            page.screenshot(path=str(screenshots / 'accueil-vue.png'))
                page.close()
            report['checks'].append('Seven pages at four viewport widths; images loaded')
            page = new_page('decouvrir.html')
            page.set_viewport_size({'width': 1440, 'height': 1000})
            if screenshots:
                page.screenshot(path=str(screenshots / 'decouvrir.png'))
            page.keyboard.press('h')
            page.wait_for_selector('#helpOverlay.open')
            page.keyboard.press('Escape')
            if page.locator('#helpOverlay').evaluate('(e)=>e.classList.contains("open")'):
                raise AssertionError('Escape did not close keyboard help')
            report['checks'].append('Native H help and Escape')
            page.keyboard.press('c')
            page.wait_for_selector('#themeMenu.open')
            page.locator('#themeOptions [data-theme="kit:lightwebpres-site@1.0.0/papier"]').click()
            page.keyboard.press('Escape')
            paper = page.evaluate('getComputedStyle(document.documentElement).getPropertyValue("--page-bg").trim()')
            if paper.lower() != '#f5f5eeff':
                raise AssertionError('The Papier theme was not applied: ' + paper)
            if screenshots:
                page.screenshot(path=str(screenshots / 'decouvrir-papier.png'))
            report['checks'].append('Native C picker changes Encre to Papier')
            # Both theme variants need an actual phone layout, not just parsed CSS.
            page.set_viewport_size({'width': 390, 'height': 844})
            if page.evaluate('document.documentElement.scrollWidth > innerWidth + 2'):
                raise AssertionError('Papier overflows on mobile')
            page.close()
            page = new_page('decouvrir.html')
            page.keyboard.press('ArrowRight')
            page.wait_for_function('scrollY > innerHeight * .5')
            page.locator('#commandes').scroll_into_view_if_needed()
            page.wait_for_timeout(400)
            page.keyboard.press('n')
            page.wait_for_function('document.getElementById("presenterNotes").textContent.includes("vraie note")')
            if screenshots:
                page.screenshot(path=str(screenshots / 'notes.png'))
            report['checks'].append('Native arrow navigation and N with real presenter notes')
            page.close()
            if render_only:
                report['skipped'] = ['HTTP link and direct-URL navigation',
                                     'Cross-page preference persistence', 'Fullscreen',
                                     'Pyodide upload/build/download end-to-end']
            else:
                page = new_page('decouvrir.html')
                page.keyboard.press('ArrowRight')
                page.wait_for_function('scrollY > innerHeight * .5')
                page.goto(base + 'decouvrir.html#commandes')
                page.keyboard.press('n')
                page.wait_for_function('document.getElementById("presenterNotes").textContent.includes("vraie note")')
                report['checks'].append('Keyboard slide navigation, direct slug link and real notes')
                page.close()
                # Actual source download, actual Pyodide compilation, actual result ZIP.
                page = new_page('web/index.html')
                page.wait_for_function('document.getElementById("status").textContent.includes("Ready.")', timeout=90000)
                page.set_input_files('#zipInput', str(root / 'downloads/demarrage.zip'))
                page.select_option('#zipLangSelect', 'fr')
                with page.expect_download(timeout=90000) as event:
                    page.click('#zipBuildBtn')
                with tempfile.TemporaryDirectory() as temporary:
                    result = Path(temporary) / 'built.zip'
                    event.value.save_as(str(result))
                    with zipfile.ZipFile(result) as archive:
                        if archive.testzip() or not any(n.endswith('ma-page.html') for n in archive.namelist()):
                            raise AssertionError('Pyodide did not generate the example page')
                report['checks'].append('Real Pyodide ZIP build and download')
                page.close()
                report['skipped'].append('Fullscreen and clipboard: manual permission-dependent checks')
            if report['page_errors'] or report['console_errors']:
                raise AssertionError('Browser errors: ' + json.dumps(report, ensure_ascii=False))
            report['passed'] = True
            return report
        finally:
            browser.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', nargs='?', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'generated/site')
    parser.add_argument('--screenshots', type=Path)
    parser.add_argument('--chromium', default=os.environ.get('PW_CHROMIUM_PATH'))
    parser.add_argument('--render-only', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    try:
        report = check(args.directory, args.screenshots, args.chromium, args.render_only)
    except Exception as exc:
        parser.exit(1, 'Browser check failed: {}\n'.format(exc))
    text = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text, encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
