import subprocess,sys
subprocess.run([sys.executable,"lightwebpres","build",".","--lang",'fr'],check=True)
